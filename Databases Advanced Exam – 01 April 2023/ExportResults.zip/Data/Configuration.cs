﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=MedicinesDb;TrustServerCertificate=True;Integrated Security=True;";
    }
}
