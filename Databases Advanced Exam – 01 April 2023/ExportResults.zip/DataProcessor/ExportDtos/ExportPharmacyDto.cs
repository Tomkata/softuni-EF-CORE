﻿namespace Medicines.DataProcessor.ExportDtos
{
    public class ExportPharmacyDto
    {
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
    }
}