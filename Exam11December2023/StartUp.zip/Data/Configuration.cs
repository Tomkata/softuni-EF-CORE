﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString =
     @"Server=.;Database=CadastreDb;TrustServerCertificate=True;Integrated Security=True;";

    }
}
